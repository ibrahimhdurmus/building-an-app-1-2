import datetime
import json

from flask import Flask, render_template, request
import requests

app_token = ('ag9zfnRlbGVmb25pLXRlc3RyHwsSElRlbmFudEFwcGxpY2F0aW9ucxiAgICw46OcCQyiARVzdGFnaW5nMS5hbG8tdGVjaC5jb20')
base_url = ('http://staging1.alo-tech.com/api/')
headers = {'Accept': 'application/json'}
base_params = {"app_token": app_token, "function": "reportsCDRLogs"}

app = Flask(__name__)


def format_datetime_for_request(datetime_object):
    return datetime_object.strftime("%Y-%m-%d %H:%M:%S")


def to_date(date_string):
    return datetime.datetime.strptime(date_string, "%Y-%m-%d %H:%M:%S").date()


def json_dumps(dict_to_json):
    return json.dumps(dict_to_json)


@app.route('/list')
def root():
    return render_template('index.html')

@app.route('/list', methods=['POST'])
def getlist():
    start_date = request.form.get('startdate', default=datetime.date.today(), type=to_date)
    finish_date = request.form.get('finishdate', default=datetime.date.today(), type=to_date)

    params = base_params.copy()
    params["startdate"] = format_datetime_for_request(start_date)
    params["finishdate"] = format_datetime_for_request(finish_date)
    r = requests.get(base_url, headers=headers, params=params)

    datas = r.json()
    if r.status_code == 200 and datas["success"]:
        return render_template('table.html', datas=datas["CallList"], jsonify_function=lambda x: json_dumps(x))
    else:
        return json.dumps({"error": "Unable to fetch data"});


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)
