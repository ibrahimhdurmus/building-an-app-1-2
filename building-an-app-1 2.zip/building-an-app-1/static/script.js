const allFields = [
    "key",
    "callid",
    "queued",
    "answered",
    "assigned",
    "abandon",
    "queuedate",
    "calldate",
    "talkdate",
    "hangupdate",
    "waitduration",
    "duration",
    "sl",
    "shortcall",
    "callerid",
    "called_num",
    "queue",
    "inbound",
    "agent",
    "agentid",
    "hold",
    "holdduration",
    "queuekey",
    "voicemail",
    "uniqueid",
    "recordingurl",
    "localrelease",
    "answeredby",
    "transferred",
];

$(function () {
    // region Datepicker initialization
    $('#startDatetimepicker').datetimepicker({
        locale: "tr",
        defaultDate: moment("2018-08-01 12:00:00")
    });
    $('#finishDatetimepicker').datetimepicker({
        useCurrent: false,
        locale: "tr",
        defaultDate: moment("2018-08-04 13:00:00")
    });
    // endregion

    // region date restriction between dates
    $("#startDatetimepicker").on("change.datetimepicker", function (e) {
        $('#finishDatetimepicker').datetimepicker('minDate', e.date);
    });
    $("#finishDatetimepicker").on("change.datetimepicker", function (e) {
        $('#startDatetimepicker').datetimepicker('maxDate', e.date);
    });
    // endregion

    $('#btnFetchData').click(function () {
        const startDateMoment = $('#startDatetimepicker').datetimepicker('viewDate');
        const finishDateMoment = $('#finishDatetimepicker').datetimepicker('viewDate');

        if (!startDateMoment.isValid() || !finishDateMoment.isValid()) {
            alert("Date is not valid!");
            return;
        }
        $.ajax({
            url: '/list',
            data: {
                startdate: startDateMoment.format("YYYY-MM-DD HH:mm:SS"),
                finishdate: finishDateMoment.format("YYYY-MM-DD HH:mm:SS"),
            },
            type: 'POST',
            success: function (response) {
                $("#table_container").html(response);
            },
            error: function (error) {
                console.error(error);
            }
        });
    });


    $(document).on("click", "td.call-date", e => {
        const seletedCall = $(e.target).closest("tr.call-data").data("calldatas");
        if (seletedCall) {
            htmlString = "";
            for (let i = 0; i < allFields.length; i++) {
                htmlString += `<div class="row">
                <div class="col-md-6">${allFields[i]}</div>
                <div class="col-md-6">${seletedCall[allFields[i]]}</div>
            </div>`
            }
            $("#detail_container").html(htmlString);
            $("#detail_modal").modal("show");
        }
    })

});